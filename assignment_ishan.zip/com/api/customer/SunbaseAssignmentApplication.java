package com.api.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunbaseAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SunbaseAssignmentApplication.class, args);
	}

}
